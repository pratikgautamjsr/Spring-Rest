package org.cap.conotroller;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.cap.dao.IEmployeeDao;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2")
public class EmployeeDbController {

	@Autowired
	private IEmployeeDao employeeDbDao;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping(path = "/employees", consumes = "application/xml")
	public ResponseEntity<List<Employee>> saveEmployee(@RequestBody Employee employee) {

		List<Employee> employees = employeeDbDao.saveEmployee(employee);

		if (employee == null) {
			return new ResponseEntity("Sorry! Employee is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping(path = "/employees", consumes = "application/xml")
	public ResponseEntity<List<Employee>> updateEmployee(@RequestBody Employee employee) {

		List<Employee> employees = employeeDbDao.updateEmployee(employee);

		if (employee == null) {
			return new ResponseEntity("Sorry! Employee is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PatchMapping(path = "/employees/{employeeId}", consumes = "application/xml")
	public ResponseEntity<List<Employee>> updateEmployeePartially(@PathVariable("employeeId") int employeeId,
			@RequestBody Map<Object, Object> fields) {

		Employee employee = employeeDbDao.findEmployee(employeeId);

		if (employee == null) {
			return new ResponseEntity("Sorry! Employee is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		fields.forEach((k, v) -> {
			Field field = ReflectionUtils.findField(Employee.class, (String) k);
			if (field != null) {
				field.setAccessible(true);
				ReflectionUtils.setField(field, employee, v);
			} else {
				field = ReflectionUtils.findField(Employee.class, (String) k);
				field.setAccessible(true);
				ReflectionUtils.setField(field, employee.getSalary(), v);
			}
		});

		List<Employee> employees = employeeDbDao.updateEmployee(employee);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@DeleteMapping(path = "/employees/{employeeId}", produces = "application/xml")
	public ResponseEntity<List<Employee>> deleteEmployee(@PathVariable("employeeId") Integer employeeId) {

		List<Employee> employees = employeeDbDao.deleteEmployee(employeeId);

		if (employees == null) {
			return new ResponseEntity("Sorry! Employee Id not exists! Deletion Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(path = "/employees", produces = "application/xml")
	public ResponseEntity<List<Employee>> getAllEmployees() {

		List<Employee> employees = employeeDbDao.getAllEmployees();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("Sorry! No Items Available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(path = "/employees/{employeeId}", produces = "application/xml")
	public ResponseEntity<Employee> findEmployees(@PathVariable("employeeId") Integer employeeId) {

		Employee employee = employeeDbDao.findEmployee(employeeId);

		if (employee == null) {
			return new ResponseEntity("Sorry!Employee Id Not Found!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
}