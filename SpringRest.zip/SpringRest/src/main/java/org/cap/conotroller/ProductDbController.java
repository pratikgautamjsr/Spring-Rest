package org.cap.conotroller;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.cap.dao.IProductDao;
import org.cap.model.Manufacturer;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/v1")
public class ProductDbController {

	@Autowired
	private IProductDao productDbDao;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping(path = "/products", consumes = "application/xml")
	public ResponseEntity<List<Product>> saveProduct(@RequestBody Product product) {

		List<Product> products = productDbDao.saveProduct(product);

		if (product == null) {
			return new ResponseEntity("Sorry! Product is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping(path = "/products", consumes = "application/xml")
	public ResponseEntity<List<Product>> updateProduct(@RequestBody Product product) {

		List<Product> products = productDbDao.updateProduct(product);

		if (product == null) {
			return new ResponseEntity("Sorry! Product is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PatchMapping(path = "/products/{id}", consumes = "application/xml")
	public ResponseEntity<List<Product>> updateProductPartially(@PathVariable int id,
			@RequestBody Map<Object, Object> fields) {

		Product product = productDbDao.findProduct(id);

		if (product == null) {
			return new ResponseEntity("Sorry! Product is not available! Save Error!", HttpStatus.NOT_FOUND);
		}

		fields.forEach((k, v) -> {
			Field field = ReflectionUtils.findField(Product.class, (String) k);
			if (field != null) {
				field.setAccessible(true);
				ReflectionUtils.setField(field, product, v);
			} else {
				field = ReflectionUtils.findField(Manufacturer.class, (String) k);
				field.setAccessible(true);
				ReflectionUtils.setField(field, product.getManufatcturer(), v);
			}
		});

		List<Product> products = productDbDao.updateProduct(product);

		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@DeleteMapping(path = "/products/{productId}", produces = "application/xml")
	public ResponseEntity<List<Product>> deleteProduct(@PathVariable("productId") Integer productId) {

		List<Product> products = productDbDao.deleteProduct(productId);

		if (products == null) {
			return new ResponseEntity("Sorry! Product Id not exists! Deletion Error!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@ApiIgnore
	@GetMapping(path = "/products", produces = "application/xml")
	public ResponseEntity<List<Product>> getAllProducts() {

		List<Product> products = productDbDao.getAllProducts();

		if (products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry! No Items Available!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(path = "/products/{productId}", produces = "application/xml")
	@ApiOperation(nickname = "AllProducts", value = "Get All Products from DB.")
	@ApiImplicitParams({ @ApiImplicitParam(value = "productId", dataType = "Integer") })
	public ResponseEntity<Product> findProducts(@PathVariable("productId") Integer productId) {

		Product product = productDbDao.findProduct(productId);

		if (product == null) {
			return new ResponseEntity("Sorry!Product Id Not Found!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
}