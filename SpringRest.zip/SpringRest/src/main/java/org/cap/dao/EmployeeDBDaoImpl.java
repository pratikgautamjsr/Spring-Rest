package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Employee;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("employeeDbDao")
public class EmployeeDBDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@SuppressWarnings("unchecked")
	public List<Employee> getAllEmployees() {
		List<Employee> employees = entityManager.createQuery("FROM Employee").getResultList();
		return employees;
	}

	@Override
	public Employee findEmployee(Integer employeeId) {
		Employee employee = entityManager.find(Employee.class, employeeId);
		return employee;
	}

	@Override
	public List<Employee> deleteEmployee(Integer employeeId) {
		Employee employee = entityManager.find(Employee.class, employeeId);
		entityManager.remove(employee);
		return getAllEmployees();
	}

	@Override
	public List<Employee> saveEmployee(Employee employee) {
		entityManager.persist(employee);
		return getAllEmployees();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		entityManager.merge(employee);
		return getAllEmployees();
	}
}