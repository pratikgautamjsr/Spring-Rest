package org.cap.dao;

import java.util.List;

import org.cap.model.Employee;

public interface IEmployeeDao {

	public List<Employee> getAllEmployees();

	public Employee findEmployee(Integer employeeId);

	public List<Employee> deleteEmployee(Integer productId);

	public List<Employee> saveEmployee(Employee employee);

	public List<Employee> updateEmployee(Employee employee);
}