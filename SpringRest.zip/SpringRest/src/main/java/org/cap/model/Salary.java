package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
public class Salary {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int salaryId;

	private double ctc;

	private double salary;

	public Salary(int salaryId, double ctc, double salary) {
		super();
		this.salaryId = salaryId;
		this.ctc = ctc;
		this.salary = salary;
	}

	public Salary() {
	}

	public int getSalaryId() {
		return salaryId;
	}

	public void setSalaryId(int salaryId) {
		this.salaryId = salaryId;
	}

	public double getCtc() {
		return ctc;
	}

	public void setCtc(double ctc) {
		this.ctc = ctc;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
}